# SPDX-License-Identifier: AGPL-3.0-or-later
# SPDX-FileCopyrightText: 2026 Advisa EOOD (Sofia, Bulgaria)
"""
Quoruna Anchoring. Standards-engagement-record path. Manifest builder.

What this module defines
------------------------

A single public function ``build_standards_engagement_manifest()`` that
returns a fully-populated ``actproof.Manifest`` for the
``op:actproof.standards_engagement_record.v1`` act type. The result is
ready for canonicalisation, signing, and anchoring by the mint script
in Step 6.3.

Module-level constants at the top of this file are the canonical source
of truth for every claim value. They are read once at function call
time. A reviewer of this file can confirm every value the receipt will
carry without running the code.

The two evidence files in ``anchoring/evidence/standards_engagement/``
are read at call time (not at module import time), so the module
imports cleanly even before the evidence directory is populated. The
builder reads the raw bytes of each file and hashes them via
``actproof.manifest.hash_file_bytes`` so the receipt commits to byte
exact file contents.

Why a separate builder module
-----------------------------

The standards-engagement-record act type is a one-shot receipt for the
STS grant application. Hard-coding the claim values in a focused module
gives auditors a single file to inspect for "what does this receipt
claim?" and the mint script in Step 6.3 a single function to call.
There is no UI surface, no database row, no HTTP endpoint for this act
type tonight. If a recurring user-facing flow becomes useful later, the
data layer can move to PostgreSQL and the builder can accept inputs
from a Pydantic request body without changing its return type.

API
---

* ``build_standards_engagement_manifest(...) -> Manifest``: returns a
  Manifest validated against the catalogue.
* ``StandardsEngagementBuildError``: raised when the builder cannot
  produce a valid Manifest (missing evidence file, catalogue does not
  contain the act type, validation issues after build).

Catalogue source
----------------

The builder uses :func:`anchoring.actproof_catalogue.get_catalogue`,
which caches the loaded ``actproof.Catalogue`` for the lifetime of the
process. When the catalogue is loaded from the installed
``actproof-events`` Python package (the expected production case), the
returned ``Catalogue`` carries ``source_package_name = "actproof-events"``
and ``source_package_version = "<wheel version>"``. The builder passes
both through to ``actproof.manifest.build_manifest`` so the receipt
records pip-installable provenance alongside the existing git-based
catalogue pinning.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from actproof.catalogue import validate_manifest
from actproof.manifest import (
    Evidence,
    Manifest,
    Recipient,
    build_manifest,
    hash_email,
    hash_file_bytes,
)

from anchoring.actproof_catalogue import get_catalogue

logger = logging.getLogger(__name__)

__all__ = [
    "build_standards_engagement_manifest",
    "StandardsEngagementBuildError",
    "ACT_TYPE_ID",
]


# ─────────────────────────────────────────────────────────────────
# CONSTANTS: canonical source of truth for every claim value
# ─────────────────────────────────────────────────────────────────

ACT_TYPE_ID: str = "op:actproof.standards_engagement_record.v1"

# Issuer identity. Authority label uses the catalogue's machine-readable
# eligible_issuer_roles vocabulary (open_source_maintainer,
# software_publisher, researcher). open_source_maintainer is the
# strongest match for Advisa EOOD's role in this engagement.
ISSUER_ORG_NAME: str = "Advisa EOOD"
ISSUER_AUTHORITY_LABEL: str = "open_source_maintainer"

# Maintainer ORCID (optional claim field). Persistent researcher
# identifier registered to Deyan Paroushev. Including it lets a verifier
# resolve the human behind the legal entity through a non-Quoruna,
# non-Advisa registry (orcid.org).
MAINTAINER_ORCID: str = "0009-0003-8231-8265"

# Required claim fields per the v3 catalogue entry shipped in Step 2.
# Maintainer is the natural person who maintains the open-source projects.
# Issuer is the legal entity that issues the receipt. ORCID ties the two
# together: a verifier resolving 0009-0003-8231-8265 reaches the same
# natural person named here. Per the STS application's own framing, the
# maintainer field is reserved for the human, not the company.
MAINTAINER_LEGAL_NAME: str = "Deyan Paroushev"
STANDARDS_BODY_NAME: str = "IETF"
WORKING_GROUP_IDENTIFIER: str = "scitt"

ENGAGEMENT_FOCUS_SUMMARY: str = (
    "Reference implementation of receipt-envelope and catalogue infrastructure "
    "aligned with the SCITT working group's architectural framing. The work "
    "covers RFC 8785 JCS canonicalisation, COSE-based signature artefacts, "
    "RFC 3161 trusted timestamping with multi-TSA failover, Algorand mainnet "
    "anchoring via ARC-2 notes, and an open, separately licensed catalogue of "
    "act types with explicit reliance and disclosure semantics. The engagement "
    "does not claim WG admission, contribution acceptance, or completion of "
    "any standards work."
)

RELATED_SPECIFICATIONS: tuple[str, ...] = (
    "draft-ietf-scitt-architecture-22",
    "draft-ietf-cose-merkle-tree-proofs-18",
    "RFC 9052",
    "RFC 9053",
    "RFC 8785",
    "RFC 3161",
    "draft-fassbender-scitt-time-anchor-01",
    "draft-hillier-scitt-arp-00",
)

IMPLEMENTATION_ARTIFACTS: tuple[str, ...] = (
    "actproof-py v0.3.3 (https://github.com/deyan-paroushev/actproof-py)",
    "actproof-events v1.4.0rc1 (https://github.com/deyan-paroushev/actproof-events)",
)

ENGAGEMENT_DATE: str = "2026-05-19"

# Human-readable title. Distinct from the legal-precision act_type_id;
# this is what a reader sees first when opening the receipt.
MANIFEST_TITLE: str = (
    "Reference implementation of SCITT-aligned receipt-envelope and "
    "catalogue infrastructure, May 2026"
)

# Recipient witnesses for this receipt. Each is a tuple of:
# (role, org_name, email_plaintext). Roles come from the catalogue
# entry's recommended_witness_roles vocabulary. Email plaintext lives
# only here at the issuer side; the manifest carries only the SHA-256
# hash of the normalised (lowercase, trimmed) email.
#
# - grant_evaluator: NLnet Foundation runs the NGI0 Commons Fund
#   evaluation, which this receipt may be cited in support of.
# - public_archive: Software Heritage operates a durable public archive
#   of source code; the implementation artefacts are eligible for
#   deposit.
# - external_auditor: a placeholder address routed back to Advisa EOOD
#   for an external technical reviewer to be named at a later date.
_RECIPIENTS: tuple[tuple[str, str, str], ...] = (
    ("grant_evaluator", "NLnet Foundation", "office@nlnet.nl"),
    ("public_archive", "Software Heritage", "info@softwareheritage.org"),
    ("external_auditor", "Independent reviewer (TBD)", "review-tbd@advisa.tech"),
)

# Evidence files live alongside this module. The builder reads them at
# call time (not import time), so the module imports cleanly even if
# the evidence directory is empty at import.
_EVIDENCE_DIR: Path = Path(__file__).parent / "evidence" / "standards_engagement"
_EVIDENCE_PATHS: dict[str, Path] = {
    "implementation_repository_state": _EVIDENCE_DIR / "implementation_repository_state.txt",
    "working_group_charter_reference": _EVIDENCE_DIR / "working_group_charter_reference.txt",
}

# Default catalogue source URI when the loaded Catalogue does not carry
# one (the installed-package case has source_uri=None unless the wheel
# embeds it). The CatalogueBinding requires a non-None string, so we
# default to the canonical GitHub URL where the bytes are versioned.
_DEFAULT_CATALOGUE_SOURCE_URI: str = (
    "https://github.com/deyan-paroushev/actproof-events"
)


# ─────────────────────────────────────────────────────────────────
# EXCEPTIONS
# ─────────────────────────────────────────────────────────────────

class StandardsEngagementBuildError(RuntimeError):
    """Raised when the standards-engagement manifest cannot be built.

    Common causes:

    * The actproof catalogue does not contain the
      op:actproof.standards_engagement_record.v1 entry. This means the
      installed actproof-events package is older than v1.4.0rc1.
    * An evidence file is missing from
      anchoring/evidence/standards_engagement/.
    * The built manifest fails post-construction catalogue validation
      (a builder bug, not a runtime configuration issue).
    """


# ─────────────────────────────────────────────────────────────────
# PUBLIC BUILDER
# ─────────────────────────────────────────────────────────────────

def build_standards_engagement_manifest(
    *,
    issued_at: Optional[str] = None,
    catalogue_git_commit: str = "",
    catalogue_source_uri: Optional[str] = None,
    title_override: Optional[str] = None,
    validate: bool = True,
) -> Manifest:
    """Build a fully-populated standards-engagement-record manifest.

    Reads the ``op:actproof.standards_engagement_record.v1`` entry from
    the cached actproof catalogue. Reads the two evidence files from
    disk and computes their SHA-256 hashes. Returns a Manifest ready to
    canonicalise, hash, sign, and anchor.

    Args:
        issued_at: ISO 8601 UTC timestamp with the ``Z`` suffix
            (``"2026-05-19T17:34:00Z"``). Defaults to "now" in UTC.
        catalogue_git_commit: 40-character git SHA-1 of the
            actproof-events repository at the version installed. The
            installed wheel does not carry this; the mint script can
            pass it through after looking it up locally. Empty string
            is permitted (the receipt's pip-installable provenance via
            source_package_name and source_package_version carries the
            equivalent durable pin).
        catalogue_source_uri: URI of the catalogue source. Defaults to
            the canonical GitHub URL.
        title_override: Override for the manifest title. Defaults to
            ``MANIFEST_TITLE`` (the module-level constant).
        validate: When True (default), run
            ``actproof.catalogue.validate_manifest`` against the built
            manifest before returning. Raises
            ``StandardsEngagementBuildError`` if any issues are found.
            Set to False only for diagnostic builds where the caller
            wants to inspect a non-conformant manifest.

    Returns:
        A fully-populated, frozen ``actproof.manifest.Manifest`` ready
        for canonicalisation.

    Raises:
        StandardsEngagementBuildError: If the catalogue does not contain
            the act type, an evidence file is missing, or post-build
            validation finds issues.
    """
    catalogue = get_catalogue()
    entry = catalogue.get(ACT_TYPE_ID)
    if entry is None:
        raise StandardsEngagementBuildError(
            f"actproof catalogue does not contain {ACT_TYPE_ID}. "
            f"The installed actproof-events package may be older than "
            f"v1.4.0rc1. Loaded entries: {sorted(catalogue.entries.keys())}."
        )

    # Build evidence list, reading each file from disk and hashing the
    # raw bytes. Validates that every required label is covered.
    evidence: list[Evidence] = []
    for label in entry.required_evidence_labels:
        path = _EVIDENCE_PATHS.get(label)
        if path is None or not path.is_file():
            raise StandardsEngagementBuildError(
                f"Required evidence file missing for label {label!r}: "
                f"expected {path}. Re-install the Step 6.2 zip into the "
                f"anchoring/evidence/standards_engagement/ directory."
            )
        raw = path.read_bytes()
        evidence.append(
            Evidence(
                label=label,
                filename_normalized=path.name,
                byte_size=len(raw),
                mime_type="text/plain",
                sha256=hash_file_bytes(raw),
            )
        )

    # Recipients, with email_hash computed via the manifest module's
    # normalisation helper for consistency with the verifier.
    recipients = tuple(
        Recipient(
            role=role,
            org_name=org_name,
            email_hash=hash_email(email),
        )
        for role, org_name, email in _RECIPIENTS
    )

    # Default issued_at to now in UTC with the canonical Z suffix that
    # actproof.manifest expects.
    if issued_at is None:
        issued_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Resolve source_uri: prefer caller's override, then the loaded
    # Catalogue's source_uri (None when loaded from installed package),
    # then the canonical GitHub URL.
    resolved_source_uri = (
        catalogue_source_uri
        or catalogue.source_uri
        or _DEFAULT_CATALOGUE_SOURCE_URI
    )

    # Build the claim dict, populating every required field and the
    # maintainer_orcid optional field.
    claim: dict[str, object] = {
        "maintainer_legal_name": MAINTAINER_LEGAL_NAME,
        "standards_body_name": STANDARDS_BODY_NAME,
        "working_group_identifier": WORKING_GROUP_IDENTIFIER,
        "engagement_focus_summary": ENGAGEMENT_FOCUS_SUMMARY,
        "related_specifications": list(RELATED_SPECIFICATIONS),
        "implementation_artifacts": list(IMPLEMENTATION_ARTIFACTS),
        "engagement_date": ENGAGEMENT_DATE,
        "maintainer_orcid": MAINTAINER_ORCID,
    }

    manifest = build_manifest(
        act_type_id=ACT_TYPE_ID,
        catalogue_entry_version=entry.version,
        catalogue_source_uri=resolved_source_uri,
        catalogue_git_commit=catalogue_git_commit,
        catalogue_entry_hash=entry.entry_hash,
        catalogue_schema_hash=catalogue.schema_hash,
        catalogue_source_package_name=catalogue.source_package_name,
        catalogue_source_package_version=catalogue.source_package_version,
        issuer_org_name=ISSUER_ORG_NAME,
        issuer_authority_label=ISSUER_AUTHORITY_LABEL,
        title=title_override or MANIFEST_TITLE,
        claim=claim,
        evidence=evidence,
        recipients=recipients,
        issued_at=issued_at,
    )

    if validate:
        issues = validate_manifest(manifest, catalogue)
        if issues:
            issue_codes = sorted({i.code for i in issues})
            raise StandardsEngagementBuildError(
                f"Built manifest failed catalogue validation. "
                f"{len(issues)} issue(s) found with codes: {', '.join(issue_codes)}. "
                f"First issue: {issues[0].message}"
            )

    logger.info(
        "Built standards-engagement manifest: title=%r, issued_at=%s, "
        "evidence_count=%d, recipient_count=%d, "
        "catalogue.source_package=%s %s",
        manifest.title,
        manifest.issued_at,
        len(manifest.evidence),
        len(manifest.recipients),
        manifest.catalogue.source_package_name or "(none)",
        manifest.catalogue.source_package_version or "",
    )
    return manifest
