# SPDX-License-Identifier: AGPL-3.0-or-later
# SPDX-FileCopyrightText: 2026 Deyan Paroushev / Advisa EOOD (Sofia, Bulgaria)
"""
Quoruna router for the DORA Article 19(4) initial notification demo.

Two endpoints make the catalogue-as-substrate story tangible:

* ``GET /lodge/dora/ict-incident-notification/initial`` renders a form
  whose structure is derived at request time from the
  ``op:eu.dora.ict_incident_notification_initial.v1`` catalogue entry
  loaded through actproof-py. Required fields, optional fields,
  required evidence labels, recommended witness roles, and the
  disclosure profile all come from the catalogue, not from this
  router. A reviewer changing the catalogue entry (or installing a
  different version of actproof-events) sees the form change without
  Quoruna code changing.

* ``POST /lodge/dora/ict-incident-notification/initial/preview`` takes
  the form data, constructs a real ``actproof.manifest.Manifest``,
  computes the manifest hash and the ARC-2 disclosed-mode note bytes
  that would be anchored on Algorand mainnet, validates the manifest
  against the catalogue, and renders a preview page showing every
  cryptographic commitment a live receipt would carry. The route does
  NOT contact KMS, algod, or any TSA. It is a preview of the
  on-chain payload, not a live anchoring path.

Why this route is here
----------------------

The standards-engagement-record receipt (mainnet TXID set out in
``receipts/``) proves Quoruna can drive the catalogue substrate end
to end for a self-referential act type. This route proves the same
substrate generalises to a recognised EU regulatory obligation:
DORA Article 19(4), supplemented by Delegated Regulation (EU)
2025/301 Article 2 and Implementing Regulation (EU) 2025/302 Annex I.

Hardening for production
------------------------

Before this route is wired into a real DORA filing flow (rather than
a demonstration), the following changes are required:

1. Authentication and authorisation. The route is currently public.
   Real DORA filings come from authenticated financial-entity users.
2. Real file upload for the two required_evidence_labels, with the
   uploaded bytes hashed and the hashes attested in the manifest.
   The current demo uses textual placeholders.
3. Wire the POST to the actproof.anchor pipeline (KMS signer, RFC
   3161 timestamp, Algorand submission) instead of the preview
   construction. The receipt then carries a real on-chain txid.
4. Replace ``input_data`` defaults below with empty initial state.
   Defaults are present for the demo so reviewers can click through
   without filling 15 fields by hand.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

logger = logging.getLogger("anchoring.lodge_dora")

router = APIRouter(prefix="/lodge/dora/ict-incident-notification/initial", tags=["lodge"])

# Templates directory is expected to sit at the project root under
# ``templates/``. The lodge/* templates live under ``templates/lodge/``.
templates = Jinja2Templates(directory="templates")


# ─────────────────────────────────────────────────────────────────
# CATALOGUE LOOKUP HELPERS
# ─────────────────────────────────────────────────────────────────

_DORA_ACT_TYPE_ID = "op:eu.dora.ict_incident_notification_initial.v1"


def _get_dora_entry() -> Any:
    """Load the catalogue (cached) and return the DORA initial entry.

    Cached via the anchoring.actproof_catalogue helper. The lookup
    fails loudly if the entry is not present, which signals an
    actproof-events install older than v1.4-rc1 with the DORA entry.
    """
    from anchoring.actproof_catalogue import get_catalogue
    catalogue = get_catalogue()
    entry = catalogue.get(_DORA_ACT_TYPE_ID)
    if entry is None:
        raise RuntimeError(
            f"Catalogue entry {_DORA_ACT_TYPE_ID!r} is not present. "
            f"Install actproof-events>=1.4-rc1 with the DORA entry "
            f"bundled, or check the catalogue resolution path."
        )
    return entry, catalogue


# ─────────────────────────────────────────────────────────────────
# DEMO DEFAULTS (CC0 fictional values matching the test vector)
# ─────────────────────────────────────────────────────────────────

_DEMO_FIELD_DEFAULTS: dict[str, Any] = {
    "entity_legal_identifier": "5493001KJTIIGC8Y1R12",
    "entity_legal_name": "Example Financial Entity S.A.",
    "submission_type": "initial",
    "incident_reference_code": "INC-2026-05-19-001",
    "detection_datetime_utc": "2026-05-19T14:32:07Z",
    "classification_datetime_utc": "2026-05-19T16:48:00Z",
    "classification_criteria_triggered": (
        "art_8_a_clients_counterparts_and_transactions, "
        "art_8_c_critical_services_affected, "
        "art_8_e_service_downtime_duration, "
        "art_8_f_geographical_spread"
    ),
    "affected_member_states": "FR, DE, IT, ES",
    "incident_discovery_method": "automated_detection_siem_rule",
    "business_continuity_plan_activated": "true",
    "affected_functions_and_services": (
        "retail_online_banking, "
        "sepa_instant_payments_outbound, "
        "mobile_banking_application_login"
    ),
    "initial_impact_description": (
        "Approximately 180,000 retail customers unable to authenticate "
        "following a JWT signing-key propagation failure after a scheduled "
        "rotation. Already-authenticated sessions unaffected. Containment "
        "in progress via roll-back to the previous signing key."
    ),
    "primary_contact_name": "Jean-Christophe Duval",
    "primary_contact_email": "jc.duval@example-financial-entity.test",
    "competent_authority": "Autorite des Marches Financiers (AMF), France",
}


# ─────────────────────────────────────────────────────────────────
# GET: render the form from the catalogue entry
# ─────────────────────────────────────────────────────────────────

@router.get("", response_class=HTMLResponse)
async def render_dora_form(request: Request) -> HTMLResponse:
    """Render the DORA initial notification form from the catalogue entry.

    Form structure (required fields, optional fields, evidence labels,
    disclosure profile, reliance text) is read live from the catalogue
    every request. Defaults are populated from a CC0 fictional example
    so reviewers can submit without filling 15 fields by hand.
    """
    entry, catalogue = _get_dora_entry()
    return templates.TemplateResponse(
        request,
        "lodge/dora_ict_incident_initial.html",
        {
            "entry": entry,
            "catalogue": catalogue,
            "defaults": _DEMO_FIELD_DEFAULTS,
        },
    )


# ─────────────────────────────────────────────────────────────────
# POST: build a real manifest, validate, show what would be anchored
# ─────────────────────────────────────────────────────────────────

@router.post("/preview", response_class=HTMLResponse)
async def preview_dora_submission(request: Request) -> HTMLResponse:
    """Build a real manifest from the form, validate against the catalogue,
    render the on-chain payload preview.

    No signing, no submission, no KMS, no algod. The route demonstrates
    that the consumer surface produces a cryptographically well-formed
    manifest that a real anchoring pipeline would commit on-chain
    byte-for-byte.
    """
    import base64
    import hashlib
    import rfc8785

    from actproof.manifest import (
        Evidence,
        Recipient,
        build_manifest,
        hash_email,
        hash_manifest,
        manifest_to_dict,
    )
    from actproof.catalogue import validate_manifest

    entry, catalogue = _get_dora_entry()

    # Parse form data. The form posts every required + optional field
    # as form-encoded strings; we coerce types as we go.
    form_data = await request.form()

    def _as_list(name: str) -> list[str]:
        """Comma-separated string from the form → list of stripped items."""
        raw = form_data.get(name, "")
        return [s.strip() for s in str(raw).split(",") if s.strip()]

    def _as_bool(name: str) -> bool:
        return str(form_data.get(name, "false")).strip().lower() in ("true", "1", "yes", "on")

    # Build the claim dict matching the catalogue's required + optional
    # fields. Type coercion is minimal; production would validate
    # against a JSON Schema generated from the entry.
    list_fields = {
        "classification_criteria_triggered",
        "affected_member_states",
        "affected_functions_and_services",
    }
    bool_fields = {"business_continuity_plan_activated"}
    int_fields = {"preliminary_estimated_clients_affected", "preliminary_estimated_financial_amount_eur"}

    claim: dict[str, Any] = {}
    for field in list(entry.required_claim_fields) + list(entry.optional_claim_fields):
        raw = form_data.get(field, "")
        if not raw and field in entry.optional_claim_fields:
            continue
        if field in list_fields:
            claim[field] = _as_list(field)
        elif field in bool_fields:
            claim[field] = _as_bool(field)
        elif field in int_fields:
            try:
                claim[field] = int(raw)
            except ValueError:
                if field in entry.optional_claim_fields:
                    continue
                raise
        else:
            claim[field] = str(raw).strip()

    # Evidence: the demo uses textual placeholders. Each evidence label
    # in the catalogue's required_evidence_labels gets a synthetic
    # Evidence record whose sha256 is computed over the placeholder
    # bytes entered in the form. Real filings would receive uploaded
    # files and compute hashes over the actual bytes.
    evidence_list: list[Evidence] = []
    for label in entry.required_evidence_labels:
        placeholder_text = str(form_data.get(f"evidence_{label}", "")).encode("utf-8")
        if not placeholder_text:
            placeholder_text = (
                f"[demo placeholder for evidence label {label}; "
                f"real filings attach the actual file]"
            ).encode("utf-8")
        h = hashlib.sha256(placeholder_text).hexdigest()
        evidence_list.append(
            Evidence(
                label=label,
                filename_normalized=f"{label}.txt",
                byte_size=len(placeholder_text),
                mime_type="text/plain",
                sha256=f"sha256:{h}",
            )
        )

    # Recipients: the demo wires two static recipients corresponding to
    # the catalogue's recommended_witness_roles. Real filings would
    # carry the issuing entity's actual contacts.
    demo_recipients = [
        Recipient(
            role="competent_authority",
            org_name=str(form_data.get("competent_authority", "Competent Authority")),
            email_hash=hash_email("incident-reporting@regulator.test"),
        ),
        Recipient(
            role="internal_compliance_officer",
            org_name=str(form_data.get("entity_legal_name", "Issuing Entity")),
            email_hash=hash_email("compliance.officer@example-entity.test"),
        ),
    ]

    issued_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    manifest = build_manifest(
        act_type_id=entry.act_type_id,
        catalogue_entry_version=entry.version,
        catalogue_source_uri="https://github.com/deyan-paroushev/actproof-events",
        catalogue_git_commit="0" * 40,
        catalogue_entry_hash=entry.entry_hash,
        catalogue_schema_hash=catalogue.schema_hash,
        catalogue_source_package_name=catalogue.source_package_name,
        catalogue_source_package_version=catalogue.source_package_version,
        issuer_org_name=str(form_data.get("entity_legal_name", "Issuing Entity")),
        issuer_authority_label="financial_entity",
        title=(
            f"DORA Article 19(4) initial notification, "
            f"incident {claim.get('incident_reference_code', '(unspecified)')}"
        ),
        claim=claim,
        evidence=evidence_list,
        recipients=demo_recipients,
        issued_at=issued_at,
    )

    # Cryptographic outputs the preview surfaces.
    manifest_hash_bytes = hash_manifest(manifest)
    manifest_hash_hex = manifest_hash_bytes.hex()

    # Build the envelope and ARC-2 note bytes (preview only).
    envelope = {
        "schema": "actproof.attestation_envelope.v1",
        "envelope_version": 1,
        "act_type_id": manifest.catalogue.act_type_id,
        "catalogue_entry_version": manifest.catalogue.entry_version,
        "manifest_hash": manifest_hash_hex,
        "merkle_root": manifest_hash_hex,
    }
    envelope_canonical = rfc8785.dumps(envelope)
    envelope_hash_hex = hashlib.sha256(envelope_canonical).hexdigest()

    arc2_inner = {
        "r": base64.urlsafe_b64encode(manifest_hash_bytes).rstrip(b"=").decode("ascii"),
        "m": 1,
        "q": "1",
        "t": "a",
        "e": base64.urlsafe_b64encode(bytes.fromhex(envelope_hash_hex)).rstrip(b"=").decode("ascii"),
        "s": manifest.catalogue.act_type_id,
    }
    arc2_inner_canonical = rfc8785.dumps(arc2_inner)
    arc2_full = b"actproof/v1:" + arc2_inner_canonical
    arc2_full_b64 = base64.b64encode(arc2_full).decode("ascii")

    # Validate the manifest against the catalogue (the 9 checks).
    issues = validate_manifest(manifest, catalogue)

    return templates.TemplateResponse(
        request,
        "lodge/dora_ict_incident_initial_preview.html",
        {
            "entry": entry,
            "catalogue": catalogue,
            "manifest_dict": manifest_to_dict(manifest),
            "manifest_hash": f"sha256:{manifest_hash_hex}",
            "envelope_hash": f"sha256:{envelope_hash_hex}",
            "envelope": envelope,
            "arc2_note_b64": arc2_full_b64,
            "arc2_note_bytes": len(arc2_full),
            "validation_issues": issues,
            "issued_at": issued_at,
        },
    )
