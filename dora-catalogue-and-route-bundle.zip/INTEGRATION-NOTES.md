# DORA filing demo: integration notes

This bundle adds a second catalogue entry to actproof-events
(`op:eu.dora.ict_incident_notification_initial.v1`) and wires it through
to a live Quoruna route at `/lodge/dora/ict-incident-notification/initial`.
The route reads the catalogue at request time, renders a form whose
structure comes from the entry (not from the template), and on submit
builds a real `actproof.manifest.Manifest`, validates against the
catalogue, and renders a preview of the cryptographic commitments a
real anchoring run would commit on-chain.

## What's in this bundle

### actproof-events delta

```
catalogue/acts/eu/dora/ict_incident_notification_initial.v1.json
catalogue/acts/eu/dora/ict_incident_notification_initial.v1.test_vectors.json
scripts/test_vector_inputs/eu_dora_ict_incident_notification_initial_v1_001.json
scripts/test_vector_inputs/eu_dora_ict_incident_notification_initial_v1_001_evidence/classification_committee_record.txt
scripts/test_vector_inputs/eu_dora_ict_incident_notification_initial_v1_001_evidence/detection_system_log_excerpt.txt
```

The catalogue entry follows the v3 schema. `regulatory_citation` is the
structured form (instrument + article + jurisdiction + in_force_from)
that matches NIS2 and EUDR entries; the supplementing regulations
(Delegated Reg 2025/301, Implementing Reg 2025/302, Reg 2024/1772) are
cited in `reliance_context.reliance_statement` which is free text.

Required claim fields: 15. Optional claim fields: 10. Required evidence
labels: 2 (`classification_committee_record`, `detection_system_log_excerpt`).
Non-claims: 7 explicit machine-readable items covering everything the
receipt does NOT prove (no admission of liability, does not replace
NIS2 or GDPR Article 33 notifications, does not exhaust the
intermediate and final reporting obligations, etc.).

The test vector hashes:

- catalogue entry hash: sha256:0b827fac026040d3b7f8cd86765be776d3128b628ad6fa10ce632ad8f82906c5
- manifest canonical bytes: 3143
- manifest hash:            sha256:7f7e45fd4fa83e158379bda46c7ed464cbb00619cc9cbd75f9c404ce04851409
- envelope hash:            sha256:ac4752a7f88c1fe6d28f4c5e03f2fed80b403c4b2dc53e44dd099d2d89b01af5
- evidence 1 (5129 B):      sha256:86eba492642a2f104b93a0043f92164b9eeca53b5d4be3dc72c54b7d87b61f22
- evidence 2 (3861 B):      sha256:cecb316cdcac886e1d224d887951b811f2f72b8c3e9abbc67aa52fc6889cacd3

End-to-end verified in the same sandbox that built all prior deliveries:
all 9 validation checks pass, manifest builds cleanly, receipt assembles
through `actproof.manifest.build_manifest` + `actproof.catalogue.validate_manifest`.

### Quoruna delta

```
routers/lodge_dora.py
templates/lodge/dora_ict_incident_initial.html
templates/lodge/dora_ict_incident_initial_preview.html
```

The router has two endpoints:

- `GET /lodge/dora/ict-incident-notification/initial` renders the form.
  Form structure is derived from the catalogue entry at request time:
  required fields, optional fields, evidence labels, disclosure profile.
  Defaults are pre-filled from a CC0 fictional example so reviewers can
  click through without typing.
- `POST /lodge/dora/ict-incident-notification/initial/preview` takes the
  form data, builds a real `Manifest`, validates against the catalogue,
  renders a preview page showing the manifest hash, envelope hash, ARC-2
  note bytes, disclosure profile applied, and what would happen next in
  production. No KMS, no algod, no TSA contact. Preview only.

The templates extend your existing `templates/base.html`. They use your
existing CSS variables (`var(--color-background-info)`, `var(--font-mono)`,
etc.) so they should look native inside Quoruna's chrome.

## Required edits to apply

### 1. Mount the router in `main.py`

Add to the existing router registrations:

```python
from anchoring import lodge_dora  # at the top with other anchoring imports
# ...
app.include_router(lodge_dora.router)
```

If your router is structured under a different package (e.g. `routers/`
instead of `anchoring/`), move `lodge_dora.py` accordingly and adjust the
import. The file does not depend on its location; only on
`anchoring.actproof_catalogue.get_catalogue()` for the cached catalogue
lookup.

### 2. Add a link from the homepage (`templates/index.html`)

Wherever you have a "See it in action" or "Roadmap" section, add a card
like this (adapt classes to your existing layout):

```html
<a href="/lodge/dora/ict-incident-notification/initial"
   style="display: block; padding: 16px; background: var(--color-background-info); border-radius: var(--border-radius-lg); text-decoration: none; color: var(--color-text-info);">
  <div style="font-size: 11px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.04em; opacity: 0.7; margin-bottom: 4px;">
    Catalogue substrate in action
  </div>
  <div style="font-size: 16px; font-weight: 500; margin-bottom: 4px;">
    DORA Article 19(4) initial notification &rarr;
  </div>
  <div style="font-size: 13px; opacity: 0.85;">
    A form auto-derived from the actproof-events v1.4-rc1 catalogue
    entry. Submit and see exactly what would be anchored on Algorand
    mainnet.
  </div>
</a>
```

### 3. Confirm `actproof-events` v1.4-rc1 (with the DORA entry) is installed

```bash
pip install --force-reinstall --no-deps \
    /path/to/actproof-events/dist/actproof_events-1.4.0rc1-py3-none-any.whl
python -c "from actproof.catalogue import load_catalogue; \
           cat = load_catalogue(); \
           assert 'op:eu.dora.ict_incident_notification_initial.v1' in cat.entries, \
               'DORA entry missing; install the rebuilt wheel'"
```

## Smoke test

Once mounted, the route should respond to:

```bash
# Local Quoruna dev server
curl -s http://localhost:8000/lodge/dora/ict-incident-notification/initial | \
    grep -c "op:eu.dora.ict_incident_notification_initial.v1"
# Expected: 1 or more (the act_type_id appears in the profile lineage band)

# POST a form submission, see the preview HTML come back
curl -sX POST http://localhost:8000/lodge/dora/ict-incident-notification/initial/preview \
    -d "entity_legal_identifier=5493001KJTIIGC8Y1R12" \
    -d "entity_legal_name=Example Financial Entity S.A." \
    -d "submission_type=initial" \
    -d "incident_reference_code=INC-2026-05-19-001" \
    -d "detection_datetime_utc=2026-05-19T14:32:07Z" \
    -d "classification_datetime_utc=2026-05-19T16:48:00Z" \
    -d "classification_criteria_triggered=art_8_a_clients_counterparts_and_transactions" \
    -d "affected_member_states=FR, DE" \
    -d "incident_discovery_method=automated_detection_siem_rule" \
    -d "business_continuity_plan_activated=true" \
    -d "affected_functions_and_services=retail_online_banking" \
    -d "initial_impact_description=Test description for smoke test." \
    -d "primary_contact_name=Test Contact" \
    -d "primary_contact_email=test@example.com" \
    -d "competent_authority=Test NCA" \
    -d "evidence_classification_committee_record=placeholder" \
    -d "evidence_detection_system_log_excerpt=placeholder" \
    | grep "Catalogue validation passed"
# Expected: a line containing "Catalogue validation passed (9 of 9 checks)"
```

If the form route returns the catalogue entry's act_type_id and the
POST returns a "validation passed" page, the integration is working.

## What this delivers for the STS narrative

The standards-engagement-record receipt (in `receipts/`) is the
**implementation proof**: one regulated act type, end-to-end, signed on
KMS, timestamped, anchored on Algorand mainnet. The DORA route is the
**substrate generalisation proof**: the same catalogue, the same
manifest builder, the same validation, working against a concrete EU
regulatory obligation (Article 19(4)) that any STS reviewer recognises.

Together they argue both axes:

- Depth: one act type fully implemented, with a mainnet anchor.
- Breadth: the substrate generalises to any regulated act expressible
  as a v3 catalogue entry. Adding the next act type is one JSON file.

The application letter can cite both: "Receipt for the engagement
record at <TXID>; live preview of the substrate at the DORA route
linked from the homepage. The next twelve regulated acts under
consideration (EUDR DDS preparation, NIS2 Article 20 management body
approval, AI Act Article 53 GPAI obligations, ...) each add a single
JSON file to the catalogue; no Quoruna code changes."

## Production hardening before this becomes a real filing flow

The route is a demonstration, not a production submission path. Before
it accepts real DORA filings, the following changes are required:

1. Authentication and authorisation (financial-entity users, role-based
   access, audit log).
2. Real file uploads for the two required_evidence_labels, with the
   uploaded bytes hashed and the hashes attested in the manifest. The
   demo uses textual placeholders.
3. Wire the POST handler to the actproof.anchor pipeline (the same
   pipeline `scripts/issue_standards_engagement_receipt.py` drives)
   instead of the preview construction. The receipt then carries a
   real on-chain txid.
4. Replace the in-code demo defaults with empty initial state. Defaults
   exist so STS reviewers can click through without filling 15 fields
   by hand; real filings come from authenticated users with their own
   data.
5. Add the time-limit enforcement (Delegated Reg 2025/301 Article 5):
   4 hours after classification, 24 hours after detection. A real flow
   computes these from `classification_datetime_utc` and
   `detection_datetime_utc` and warns the user if the deadline is
   approaching or missed.
6. Add the intermediate and final report linkability (one act type
   entry each, with `prior_receipts_profile` carrying
   `linked_initial_notification` in their reliance_context).
